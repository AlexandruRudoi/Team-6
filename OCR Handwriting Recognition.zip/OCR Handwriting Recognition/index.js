const imageUpload = document.getElementById('image-upload');
const previewContainer = document.querySelector('.preview-container');

function createImagePreview(file) {
  const reader = new FileReader();
  reader.onload = (event) => {
    const img = document.createElement('img');
    img.src = event.target.result;
    previewContainer.innerHTML = '';
    previewContainer.appendChild(img);
  };
  reader.readAsDataURL(file);
}

imageUpload.addEventListener('change', (event) => {
  const file = event.target.files[0];
  createImagePreview(file);
});

// Drag and drop functionality (optional)
const dropzone = document.querySelector('.upload-container');

dropzone.addEventListener('dragover', (event) => {
  event.preventDefault();
});

dropzone.addEventListener('drop', (event) => {
  event.preventDefault();
  const file = event.dataTransfer.files[0];
  createImagePreview(file);
});
